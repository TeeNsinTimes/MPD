#ifndef __STDDEF_H___
#define __STDDEF_H___

typedef unsigned long size_t;
#define NULL 0

#endif
